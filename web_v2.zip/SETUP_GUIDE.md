# Firebase Chat Setup Guide

## What You'll Get
✅ Real-time chat that works across multiple devices  
✅ Live user presence (see who's online)  
✅ Typing indicators  
✅ File sharing up to 10MB  
✅ Message history (last 100 messages)  
✅ Password protection  

---

## Quick Setup (5 minutes)

### Step 1: Create a Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Click **"Add project"** or **"Create a project"**
3. Enter a project name (e.g., "FriendsChat")
4. Click **Continue**
5. Disable Google Analytics (not needed) and click **Create project**
6. Wait for project creation, then click **Continue**

### Step 2: Enable Realtime Database

1. In the left sidebar, click **Build** → **Realtime Database**
2. Click **"Create Database"**
3. Select your location (choose closest to you)
4. Start in **"Test mode"** for now (we'll secure it later)
5. Click **Enable**

### Step 3: Get Your Firebase Configuration

1. Click the **⚙️ gear icon** (Settings) → **Project settings**
2. Scroll down to **"Your apps"** section
3. Click the **</>** (Web) icon
4. Give it a nickname (e.g., "Chat App")
5. Click **Register app**
6. You'll see a `firebaseConfig` object - **COPY THIS!**

It looks like this:
```javascript
const firebaseConfig = {
  apiKey: "AIzaSyC...",
  authDomain: "your-project.firebaseapp.com",
  databaseURL: "https://your-project-default-rtdb.firebaseio.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456"
};
```

### Step 4: Update Your Chat HTML File

1. Open `secure-chat-firebase.html` in a text editor
2. Find line ~520 (search for `YOUR_API_KEY`)
3. Replace the entire `firebaseConfig` object with yours
4. Save the file

### Step 5: Test It Out!

1. Open the HTML file in your browser
2. The yellow setup notice should disappear
3. Enter your name and password: `friends2025`
4. You're in! 🎉

### Step 6: Share With Friends

To let others join:
1. **Share the HTML file** - Send them the file
2. **Share the password** - Tell them: `friends2025`
3. They need to open it in their browser

OR host it online (see Advanced Setup below)

---

## How to Use

### Basic Chat
- Type a message and press Enter or click Send
- Messages appear in real-time for everyone
- You'll see when others are typing

### File Sharing
- Click the 📎 icon
- Select a file (max 10MB)
- Everyone can download it by clicking

### Online Users
- See who's online in the left sidebar
- Users automatically appear/disappear

---

## Security Setup (Recommended)

Right now, anyone with the database URL could access your data. Let's secure it:

### Option 1: Password-Only (Current)
- Only people with the HTML file + password can join
- Good for: Small groups of friends

### Option 2: Secure Database Rules

1. In Firebase Console → **Realtime Database** → **Rules** tab
2. Replace with:
```json
{
  "rules": {
    ".read": "auth != null",
    ".write": "auth != null"
  }
}
```
3. This requires authentication (more setup needed)

### Option 3: Simple Access Control
```json
{
  "rules": {
    "messages": {
      ".read": true,
      ".write": true
    },
    "users": {
      ".read": true,
      ".write": true
    }
  }
}
```
⚠️ This allows anyone to read/write if they know your database URL

### Best Practice
For better security, add Firebase Authentication:
- Add email/password login
- Use secure database rules
- This requires code changes (let me know if you want this!)

---

## Advanced: Hosting Online

Instead of sharing the HTML file, host it online:

### Option A: Firebase Hosting (Free)
1. Install Firebase tools: `npm install -g firebase-tools`
2. Run: `firebase init hosting`
3. Choose your project
4. Set `public` directory to where your HTML is
5. Run: `firebase deploy`
6. You'll get a URL like: `https://your-project.web.app`

### Option B: GitHub Pages (Free)
1. Create a GitHub repository
2. Upload your HTML file
3. Go to Settings → Pages
4. Enable GitHub Pages
5. Your URL: `https://yourusername.github.io/repo-name`

### Option C: Netlify/Vercel (Free)
1. Sign up at [Netlify](https://netlify.com) or [Vercel](https://vercel.com)
2. Drag and drop your HTML file
3. Get instant URL

---

## Customization

### Change Password
Line 510: `const ROOM_PASSWORD = 'friends2025';`

### Change App Name
Line 6: `<title>Your Chat Name</title>`  
Line 422: `<h2>💬 Your Chat Name</h2>`

### Message Limit
Line 649: `.limitToLast(100)` - Change 100 to your desired limit

### File Size Limit
Line 687: `10 * 1024 * 1024` - This is 10MB in bytes

---

## Troubleshooting

### "Firebase setup error"
- Check your firebaseConfig is correct
- Make sure you replaced ALL the placeholder values
- Verify Realtime Database is enabled

### Messages not syncing
- Check your internet connection
- Open browser console (F12) for errors
- Verify database rules allow read/write

### File upload fails
- Check file size (max 10MB)
- Try a smaller file
- Check browser console for errors

### Can't see other users
- Make sure you're both logged in
- Refresh the page
- Check if you're using the same Firebase project

---

## What's Next?

Want to add more features? I can help you add:
- ✨ Image previews for image files
- 🔔 Sound notifications for new messages
- 🌙 Dark mode
- 📝 Message editing/deletion
- 👤 User avatars
- 🔐 Better authentication
- 📱 Mobile app version

Just ask! 🚀
